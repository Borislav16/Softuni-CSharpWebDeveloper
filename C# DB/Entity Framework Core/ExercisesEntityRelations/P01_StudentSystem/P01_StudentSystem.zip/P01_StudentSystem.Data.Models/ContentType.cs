﻿namespace P01_StudentSystem.Data.Models
{
    public enum ContentType
    {
        Application = 0,
        Pdf = 1,
        Zip = 2,
    }
}