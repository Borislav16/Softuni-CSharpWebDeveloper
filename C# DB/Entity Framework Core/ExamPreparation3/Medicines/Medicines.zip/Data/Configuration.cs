﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = "Server=.\\SQLEXPRESS;Database=BoardgamesEF;Integrated Security=True";
    }
}
