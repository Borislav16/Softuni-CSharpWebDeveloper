﻿namespace MusicHub
{
    using System;
    using System.Text;
    using Data;
    using Initializer;
    using Microsoft.EntityFrameworkCore;
    using MusicHub.Data.Models;

    public class StartUp
    {
        public static void Main()
        {



            MusicHubDbContext context =
                new MusicHubDbContext();

            //DbInitializer.ResetDatabase(context);

            //Test your solutions here
            Console.WriteLine(ExportAlbumsInfo(context, 9));

        }

        public static string ExportAlbumsInfo(MusicHubDbContext context, int producerId)
        {

            var albumsInfo = context.Producers
                .Include(p => p.Albums)
                .ThenInclude(a => a.Songs)
                .ThenInclude(s => s.Writer)
                .First(p => p.Id == producerId)
                .Albums.Select(a => new
                {
                    AlbumName = a.Name,
                    a.ReleaseDate,
                    ProducerName = a.Producer.Name,
                    AlbumSongs = a.Songs.Select(s => new
                    {
                        SongName = s.Name,
                        SongPrice = s.Price,
                        SongWriterName = s.Writer.Name
                    })
                    .OrderByDescending(s => s.SongName)
                    .ThenBy(s => s.SongWriterName),
                    TotalAlbumPrice = a.Price,

                })
                .OrderByDescending(s => s.TotalAlbumPrice)
                .ToList();

            StringBuilder stringBuilder = new StringBuilder();

            foreach (var album in albumsInfo)
            {
                stringBuilder.AppendLine($"-AlbumName: {album.AlbumName}");
                stringBuilder.AppendLine($"-ReleaseDate: {album.ReleaseDate.ToString("MM/dd/yyyy")}");
                stringBuilder.AppendLine($"-ProducerName: {album.ProducerName}");
                stringBuilder.AppendLine($"-Songs:");

                int count = 1;
                foreach (var song in album.AlbumSongs)
                {
                    stringBuilder.AppendLine($"---#{count++}");
                    stringBuilder.AppendLine($"---SongName: {song.SongName}");
                    stringBuilder.AppendLine($"---Price: {song.SongPrice:F2}");
                    stringBuilder.AppendLine($"---Writer: {song.SongWriterName}");

                }

                stringBuilder.AppendLine($"-AlbumPrice: {album.TotalAlbumPrice:F2}");
            }

            return stringBuilder.ToString().Trim();
        }

        public static string ExportSongsAboveDuration(MusicHubDbContext context, int duration)
        {
            throw new NotImplementedException();
        }
    }
}
