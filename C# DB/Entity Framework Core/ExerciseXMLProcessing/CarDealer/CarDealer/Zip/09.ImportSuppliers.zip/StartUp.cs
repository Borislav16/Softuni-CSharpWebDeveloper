﻿using AutoMapper;
using CarDealer.Data;
using CarDealer.DTOs.Import;
using CarDealer.Models;
using System.Xml.Serialization;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main()
        {
            CarDealerContext context = new CarDealerContext();

            string path = File.ReadAllText("../../../Datasets/suppliers.xml");

            Console.WriteLine(ImportSuppliers(context, path));
        }

        private static Mapper GetMapper()
        {
            var cfg = new MapperConfiguration(c => c.AddProfile<CarDealerProfile>());
            return new Mapper(cfg);
        }

        //09
        public static string ImportSuppliers(CarDealerContext context, string inputXml)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(ImportSuppliersDTO[]),
                new XmlRootAttribute("Suppliers"));

            using StringReader reader = new StringReader(inputXml);

            ImportSuppliersDTO[] importSupplierDTOs = (ImportSuppliersDTO[])xmlSerializer.Deserialize(reader);

            var mapper = GetMapper();
            Supplier[] suppliers = mapper.Map<Supplier[]>(importSupplierDTOs);

            context.AddRange(suppliers);
            context.SaveChanges();  

            return $"Successfully imported {suppliers.Count()}";
        }
    }
}