﻿using SoftUni.Data;
namespace SoftUni
{
    public class Program
    {
        static void Main(string[] args)
        {
            SoftUniContext context = new SoftUniContext();
            var employee = context.Employees.Find(2);
            Console.WriteLine(employee.FirstName);
        }
    }
}
