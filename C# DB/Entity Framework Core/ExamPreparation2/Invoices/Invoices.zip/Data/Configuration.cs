﻿namespace Invoices.Data
{
    public static class Configuration
    {
        public static string ConnectionString = "Server=.\\SQLEXPRESS;Database=InvoicesEF;Integrated Security=True";
    }
}
