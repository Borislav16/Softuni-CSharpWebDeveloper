﻿namespace TravelAgency.Data.Models
{
    public enum Language
    {
        English,
        German,
        French,
        Spanish,
        Russian,
    }
}