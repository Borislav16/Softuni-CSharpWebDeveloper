﻿using Newtonsoft.Json;
using ProductShop.Data;
using ProductShop.Models;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main()
        {
            ProductShopContext context = new ProductShopContext();
            string userJson = File.ReadAllText("../../../Datasets/categories.json");

            
            Console.WriteLine(ImportCategories(context, userJson));
        }

        //01
        public static string ImportUsers(ProductShopContext context, string inputJson)
        {
            var users = JsonConvert.DeserializeObject<User[]>(inputJson);

            context.Users.AddRange(users);

            context.SaveChanges();
            return $"Successfully imported {users.Count()}"; ;
        }

        //02
        public static string ImportProducts(ProductShopContext context, string inputJson)
        {
            var product = JsonConvert.DeserializeObject<Category[]>(inputJson);

            

            if (product is not null)
            {
                context.Categories.AddRange(product);
                context.SaveChanges();

            }
                return $"Successfully imported {product.Count()}";
        }

        //03
        public static string ImportCategories(ProductShopContext context, string inputJson)
        {
            var categories = JsonConvert.DeserializeObject<Category[]>(inputJson);

            var validCategories = categories?.Where(c => c.Name is not null).ToList();

            if (validCategories is not null)
            {
                context.Categories.AddRange(validCategories);
                context.SaveChanges();
                return $"Successfully imported {validCategories.Count()}";

            }


            return $"Successfully imported 0";
        }
    }
}